package com.hillel.Task_28_SpringData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task28SpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
