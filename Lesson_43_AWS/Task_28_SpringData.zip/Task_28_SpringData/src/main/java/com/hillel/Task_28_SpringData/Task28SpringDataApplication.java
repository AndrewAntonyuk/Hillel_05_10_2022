package com.hillel.Task_28_SpringData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task28SpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(Task28SpringDataApplication.class, args);
	}

}
